SELAH – Gebetsjournal (PWA-Prototyp)

So veröffentlichst du es nur mit dem Handy:
1. Öffne github.com im Browser und melde dich an oder erstelle ein Konto.
2. Erstelle ein neues öffentliches Repository, z. B. selah-gebetsjournal.
3. Lade die vier Dateien aus diesem ZIP in das Repository hoch: index.html, manifest.webmanifest, sw.js, icon.svg.
4. In Repository Settings → Pages wähle Deploy from a branch, Branch main, Folder /(root), dann Save.
5. Warte, bis GitHub Pages die Website veröffentlicht hat.
6. Öffne die veröffentlichte HTTPS-Adresse in Chrome auf Android. Menü ⋮ → „App installieren“ oder „Zum Startbildschirm hinzufügen“.

Datenschutz:
- Tagebuchdaten werden aktuell im lokalen Browserspeicher (localStorage) auf dem Gerät gespeichert.
- Die Daten werden nicht synchronisiert oder automatisch gesichert.
- Browserdaten löschen kann Einträge löschen. Nutze „Daten exportieren“ regelmäßig.
- Dies ist ein Prototyp, kein unabhängig geprüfter sicherer Tresor für hochsensible Daten.
- Für iPhone lässt sich die Website über Safari → Teilen → Zum Home-Bildschirm hinzufügen testen; Installation und Offline-Verhalten können je nach iOS-Version variieren.
